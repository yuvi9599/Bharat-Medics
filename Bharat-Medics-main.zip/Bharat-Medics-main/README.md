# Bharat-Medics
 A Doctor Booking Web App.

 Users : https://bharat-medics.onrender.com/

 Admin & Doctors : https://bharat-medics-admin.onrender.com/
